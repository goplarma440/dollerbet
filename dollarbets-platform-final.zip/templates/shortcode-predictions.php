<?php
// Placeholder for prediction shortcode template
?>
<div id="dollarbets-prediction-app">
    Loading predictions...
</div>


